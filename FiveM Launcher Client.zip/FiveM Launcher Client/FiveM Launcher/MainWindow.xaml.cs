﻿using Fujino.KCLauncher.Connect;
using Fujino.KCLauncher.XML;
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace FiveM_Launcher
{
    public partial class MainWindow : Window
    {
        Data_Settings _Settings = new Data_Settings();
        KC_Connection _Connection = new KC_Connection();

        public MainWindow()
        {
            InitializeComponent();
            this.Title = Assembly.GetExecutingAssembly().GetName().Name;
            this.lbl_title.Content = " " + Assembly.GetExecutingAssembly().GetName().Name + " V" + Assembly.GetExecutingAssembly().GetName().Version.ToString();
            if (File.Exists("DataSettings.xml"))
            {
                _Settings = KC_XmlManager.Data_Settings_Reader("DataSettings.xml");
                this.txt_server.Text = _Settings.URL;
                this.txt_ts.Text = _Settings.IPTS;
            }
            else
            {
                _Settings.URL = "";
                _Settings.IPTS = "";
                KC_XmlManager.KC_XmlDataWriter(_Settings, "DataSettings.xml");
            }

        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                this.DragMove();
            }
        }

        private void btn_exit_app_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btn_connect_Click(object sender, RoutedEventArgs e)
        {
            this.Connnect();
        }

        private async void Connnect()
        {
            try
            {
                if (this.txt_server.Text == "")
                {
                    MessageBox.Show("Please enter server IP or JoinID before connecting to server!\n\nโปรดใส่ IP Server หรือJoinID ก่อนกดปุ่มเชื่อมต่อเซิร์ฟเวอร์!", "Warning!", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    _Settings.URL = this.txt_server.Text;
                    _Settings.IPTS = this.txt_ts.Text;
                    KC_XmlManager.KC_XmlDataWriter(_Settings, "DataSettings.xml");

                    _Settings = KC_XmlManager.Data_Settings_Reader("DataSettings.xml");
                    this.txt_server.Text = _Settings.URL;
                    this.txt_ts.Text = _Settings.IPTS;

                    _Connection.CMDConnectionFiveM(_Settings.URL);
                    if (_Settings.IPTS != "")
                    {
                        _Connection.CMDConnectionTeamSpeak(_Settings.IPTS);
                    }

                    await Task.Delay(2000);
                    Application.Current.Shutdown();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                Application.Current.Shutdown();
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (Keyboard.GetKeyStates(Key.Enter) == KeyStates.Down)
            {
                this.Connnect();
            }
        }

        private async void lbl_togithub_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Process.Start("https://fujinons.web.app/credit/");
            await Task.Delay(500);
            Process.Start("https://github.com/FujinoNs/FiveM-Launcher-Client");
        }

        private void btn_tip_fivem_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Enter IP Server or JoinID (cfx.re/join/????) of server you want to connect to in Textbox.\n\nนำเลข IP Server หรือ JoinID (cfx.re/join/????) ของเซิร์ฟเวอร์ที่คุณต้องการเชื่อมต่อใส่ลงในช่องกรอกข้อความ", "How to Use?", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void btn_tip_ts_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Enter IP Server of TeamSpeak (TokoVoip) server you wish to connect to in Textbox. Please leave blank if not in use.\n\nนำเลข IP Server ของเซิร์ฟเวอร์ TeamSpeak (TokoVoip) ที่คุณต้องการเชื่อมต่อใส่ลงในช่องกรอกข้อความ โปรดปล่อยว่างหากไม่ใช้งาน", "How to Use?", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void btn_tip_connect_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Press button to allow program to automatically connect to FiveM and TeamSpeak (if enabled). The program will close after 2 seconds of pressing button.\n\nกดปุ่มเพื่อให้โปรแกรมทำการเชื่อมต่อกับ FiveM และ TeamSpeak(หากใช้งาน) อัตโนมัติ โปรแกรมจะปิดตัวเองหลังจากกดปุ่มใน 2 วินาที", "How to Use?", MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}

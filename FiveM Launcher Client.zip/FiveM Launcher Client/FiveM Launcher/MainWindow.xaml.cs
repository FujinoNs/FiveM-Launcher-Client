﻿using Fujino.KCLauncher.XML;
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Input;

namespace FiveM_Launcher
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Data_Settings _Settings = new Data_Settings();

        public MainWindow()
        {
            InitializeComponent();
            this.Title = Assembly.GetExecutingAssembly().GetName().Name;
            this.lbl_title.Content = " " + Assembly.GetExecutingAssembly().GetName().Name + " V" + Assembly.GetExecutingAssembly().GetName().Version.ToString();
            if (File.Exists("DataSettings.xml"))
            {
                _Settings = KC_XmlManager.Data_Settings_Reader("DataSettings.xml");
                this.txt_server.Text = _Settings.URL;
                this.txt_path.Text = _Settings.Path;

                if (_Settings.Delete == "Y")
                {
                    this.btncb_delete_cache.IsChecked = true;
                }
                else if (_Settings.Delete == "N")
                {
                    this.btncb_delete_cache.IsChecked = false;
                }
            }
            else
            {
                _Settings.URL = "";
                _Settings.Path = "";
                _Settings.Delete = "N";
                KC_XmlManager.KC_XmlDataWriter(_Settings, "DataSettings.xml");
            }

        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                this.DragMove();
            }
        }

        private void btn_exit_app_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btn_connect_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (this.txt_path.Text == "")
                {
                    MessageBox.Show("Please enter the FiveM.exe address before connecting to the server!\n(โปรดใส่ที่อยู่ FiveM.exe ก่อนเชื่อมต่อเซิร์ฟเวอร์!)", "แจ้งเตือน!", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    _Settings.Path = this.txt_path.Text;
                    KC_XmlManager.KC_XmlDataWriter(_Settings, "DataSettings.xml");
                    _Settings = KC_XmlManager.Data_Settings_Reader("DataSettings.xml");
                    if (File.Exists(_Settings.Path + "/FiveM.exe"))
                    {
                        if (this.txt_server.Text == "")
                        {
                            MessageBox.Show("Please enter server IP or JoinID before connecting to server!\n(โปรดใส่ ไอพีเซิร์ฟเวอร์ หรือJoinID ก่อนเชื่อมต่อเซิร์ฟเวอร์!)", "แจ้งเตือน!", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                        else
                        {
                            _Settings.URL = this.txt_server.Text;
                            KC_XmlManager.KC_XmlDataWriter(_Settings, "DataSettings.xml");

                            _Settings = KC_XmlManager.Data_Settings_Reader("DataSettings.xml");
                            txt_server.Text = _Settings.URL;
                            
                            ProcessStartInfo startInfo = new ProcessStartInfo();
                            startInfo.WindowStyle = ProcessWindowStyle.Hidden;
                            startInfo.FileName = "powershell.exe";
                            startInfo.Arguments = "\"& '" + _Settings.Path + "/FiveM.exe' \"fivem://connect/" + _Settings.URL;
                            Process Process = new Process();
                            Process.StartInfo = startInfo;
                            Process.Start();

                            if (this.btncb_delete_cache.IsChecked == true)
                            {
                                _Settings.Delete = "Y";
                                KC_XmlManager.KC_XmlDataWriter(_Settings, "DataSettings.xml");

                                _Settings = KC_XmlManager.Data_Settings_Reader("DataSettings.xml");
                                if (_Settings.Delete == "Y")
                                {
                                    this.btncb_delete_cache.IsChecked = true;
                                    this.DeleteCache(_Settings.Path + @"\FiveM.app\cache\priv\");
                                }
                            }
                            else if (this.btncb_delete_cache.IsChecked == false)
                            {
                                _Settings.Delete = "N";
                                KC_XmlManager.KC_XmlDataWriter(_Settings, "DataSettings.xml");
                            }

                            this.TimerExit(0, 0, 3);
                        }
                    }
                    else
                    {
                        MessageBox.Show("FiveM.exe file could not be found, please try again!\n(ไม่พบไฟล์ FiveM.exe โปรดลองใหม่อีกครั้ง!)", "แจ้งเตือน!", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                Application.Current.Shutdown();
            }
        }

        private void TimerExit(int h, int m, int s)
        {
            System.Windows.Threading.DispatcherTimer _timer = new System.Windows.Threading.DispatcherTimer();
            _timer.Tick += TimerTick;
            _timer.Interval = new TimeSpan(h, m, s);
            _timer.Start();
        }

        private void TimerTick(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void DeleteCache(string Path)
        {
            try
            {
                Directory.Delete(Path, true);
            }
            catch (Exception ex) { }
        }

        private void btncb_delete_cache_Click(object sender, RoutedEventArgs e)
        {
            if (this.btncb_delete_cache.IsChecked == true)
            {
                this.btncb_delete_cache.IsChecked = false;
                MessageBoxResult result = MessageBox.Show("Are you sure you want to delete cache every time you start a game?\n(คุณแน่ใจใช่หรือไม่ที่จะลบแคชทุกครั้งที่คุณกดเริ่มเกม?)", "แจ้งเตือน!", MessageBoxButton.YesNo, MessageBoxImage.Question);
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        this.btncb_delete_cache.IsChecked = true;
                        break;
                    case MessageBoxResult.No:
                        this.btncb_delete_cache.IsChecked = false;
                        break;
                }
            }
        }
    }
}

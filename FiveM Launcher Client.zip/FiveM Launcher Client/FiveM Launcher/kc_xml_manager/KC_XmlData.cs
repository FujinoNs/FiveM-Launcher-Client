﻿namespace Fujino.KCLauncher.XML
{
    public class Data_Settings
    {
        private string _Data_URL;
        public string URL
        {
            get { return _Data_URL; }
            set { _Data_URL = value; }
        }

        private string _Data_Path;
        public string Path
        {
            get { return _Data_Path; }
            set { _Data_Path = value; }
        }
    }
}
